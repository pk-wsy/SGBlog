create definer = root@localhost view employee_vu as
select `atguigudb`.`employees`.`last_name`     AS `last_name`,
       `atguigudb`.`employees`.`employee_id`   AS `employee_id`,
       `atguigudb`.`employees`.`department_id` AS `department_id`
from `atguigudb`.`employees`
where (`atguigudb`.`employees`.`department_id` = 80);


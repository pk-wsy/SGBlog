create
    definer = root@localhost function add_float(f1 float, f2 float) returns float
BEGIN
		RETURN (f1+f2);
	END;


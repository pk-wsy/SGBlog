create definer = root@localhost view emp_v1 as
select `atguigudb`.`emps`.`last_name`    AS `last_name`,
       `atguigudb`.`emps`.`email`        AS `email`,
       `atguigudb`.`emps`.`phone_number` AS `phone_number`
from `atguigudb`.`emps`
where ((`atguigudb`.`emps`.`phone_number` like '011%') and (`atguigudb`.`emps`.`email` like '%e%'));


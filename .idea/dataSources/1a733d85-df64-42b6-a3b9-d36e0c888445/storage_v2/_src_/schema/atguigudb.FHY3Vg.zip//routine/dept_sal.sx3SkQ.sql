create
    definer = root@localhost function dept_sal(dept_name varchar(20)) returns double
BEGIN 
		
		RETURN(
			SELECT avg(salary)
			FROM employees
			WHERE department_id = (
						SELECT department_id
						FROM departments
						WHERE department_name=dept_name
						)
			GROUP BY department_id
			
			);
	END;

